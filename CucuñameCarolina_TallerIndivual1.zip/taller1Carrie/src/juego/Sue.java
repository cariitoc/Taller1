package juego;

import Comunicacion.Receptor;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;
import Comunicacion.Mensaje;

public class Sue extends Personaje {

	/*
	 * Constructor del JugadorA que solo recibe una variable Logica y en el que se
	 * incializacian los booleans ,se cargan las imagenes y la posicion del
	 * personajes
	 */

	public Sue(Logica log, PVector pos) {
		super(log, pos);

		perso[0] = new Anim(app, pos, "Imagenes/Personaje/sue/1");
		perso[1] = new Anim(app, pos, "Imagenes/Personaje/sue/2");
		perso[2] = new Anim(app, pos, "Imagenes/Personaje/sue/3");
		perso[3] = new Anim(app, pos, "Imagenes/Personaje/sue/up", 2);
		perso[4] = new Anim(app, pos, "Imagenes/Personaje/sue/atackL", 2);
		perso[5] = new Anim(app, pos, "Imagenes/Personaje/sue/atackR", 2);

		contSalto = 0;
		name = "sue";
		start();

	}

	// Metodo para pintar el personaje y recorrer el metodo de movimiento todo el
	// tiempo
	public void pintar() {
		app.imageMode(PConstants.CENTER);
		perso[vista].pintar();
		perso[vista].play();
		pararTodos();

		if (PApplet.dist(pos.x, pos.y, 590, 100) < 200) {
			if (log.pantalla == 2) {
				log.pantalla = 3;
			}
		}

	}

	/*
	 * Metodo para cuando el personaje cuando se opriman las teclas el se mueva para
	 * la posicion respectivas teclas y la accion de saltar
	 */

	public void pararTodos() {
		for (int i = 0; i < perso.length; i++) {
			if (i != vista) {
				perso[i].detener();
			}
		}
	}

	// Metodos de comunicacion del cliente con el personaje----------------------

	// Metodo para asignar las teclas a los movimientos del personaje en un swicth
	public void keyPressed() {

		if (app.key == app.CODED) {

			switch (app.keyCode) {

			case PConstants.RIGHT:

				seMovio[0] = true;

				break;

			case PConstants.LEFT:
				seMovio[1] = true;
				break;

			// case PConstants.UP:
			// if (!obstaculo.down()) {
			// seMovio[2] = true;
			// }
			// break;

			}
		}

	}

	// Metodo para saber si el personaje no se esta moviendo con ninguna de las
	// teclas
	public void keyReleased() {

		if (app.key == app.CODED) {

			switch (app.keyCode) {

			case PConstants.RIGHT:
				seMovio[0] = false;
				break;

			case PConstants.LEFT:
				seMovio[1] = false;
				break;

			case PConstants.UP:
				// seMovio[2] = false;
				break;

			}
		}

		seMovio[0] = false;
		seMovio[1] = false;
	}

	@Override
	public void Mensaje(Mensaje o) {
		controlCom(o);

	}

}
