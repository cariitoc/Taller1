package juego;

import java.util.ArrayList;

import Comunicacion.Servidor;
import Comunicacion.Mensaje;
import Comunicacion.Receptor;
import Comunicacion.Receptor.Notificacion;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

public abstract class Personaje extends Thread implements Notificacion {

	protected PApplet app;
	protected Logica log;
	protected PVector pos;
	protected PVector vel;
	protected int vista;
	protected Receptor receptor;
	protected int width, height;
	protected PImage personaje;
	protected Anim[] perso;
	protected boolean isVivo;
	protected boolean subir;
	protected Escalera escalera;
	protected int vida;
	protected Obstaculo obs;
	protected String name;
	protected boolean[] seMovio; // variable para saber si el personaje se movio
	protected Comunicacion.Mensaje comando;
	protected boolean presion;
	protected int contSalto; // variable contador para ??

	public Personaje(Logica log, PVector pos) {
		this.log = log;
		this.app = log.getPApplet();

		comando = new Comunicacion.Mensaje();
		perso = new Anim[6];
		presion = false;
		vida = 100;

		personaje = app.loadImage("Imagenes/sue.png");
		this.pos = new PVector(0, 0);
		this.vel = new PVector(5, 7);
		this.isVivo = true;
		this.width = personaje.width;
		this.height = personaje.height;

		System.out.println(width + " " + height);
		this.pos = pos;
		this.seMovio = new boolean[6];
		// this.obstaculo = new Obstaculo(log, this);

		seMovio[5] = false;

		obs = new Obstaculo(log, this);

	}

	public abstract void pintar();

	public void mover(float x, float y) {
		this.pos.x = x;
		this.pos.y = y;
	}

	@Override
	public void run() {

		while (isVivo) {
			try {
				if (log.pantalla == 2) {
					movimiento();
				}

				sleep(25);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public boolean isSobre(float x, float y) {
		boolean sobre = false;
		if (PApplet.dist(pos.x, pos.y, x, y) < width) {
			sobre = true;
		}
		return sobre;
	}

	public void gravedad() {
		pos.y += 4;
	}

	public void saltar() {
		if (seMovio[2]) {

			if (contSalto < 30) {
				contSalto++;
				pos.y -= vel.y;
			} else if (!obs.down()) {
				contSalto = 0;
				seMovio[2] = false;
			}

		}
	}

	public void movimiento() {

		if (seMovio[0] && obs.right() && !obs.limRight()) {
			pos.x += vel.x;
			vista = 2;
		}

		if (seMovio[1] && obs.left() && !obs.limLeft()) {
			pos.x -= vel.x;
			vista = 1;

		}
		if (seMovio[4]) {
			// pos.y -= vel.y;

		}

		escalar();

		saltar();

		ataque();

		if (obs.down() && subir == false) {
			gravedad();

		}

	}

	public void ataque() {

		if (seMovio[5]) {
			if (vista == 1) {
				vista = 4;
			} else if (vista == 2) {
				vista = 5;
			}
		} else if (vista == 4) {
			vista = 1;
		} else if (vista == 5) {
			vista = 2;
		}

	}

	public void recoger() {

	}

	public void escalar() {

		if (subir == false) {
			for (int i = 0; i < log.getEsc().size(); i++) {
				Escalera esca = log.getEsc().get(i);

				if (isSobreEscalera(esca) && esca.tipo != 3) {
					subir = true;
					escalera = esca;

				}
			}
		}

		if (escalera != null) {
			if (isSobreEscalera(escalera)) {
				if (seMovio[2]) {
					pos.y -= vel.y;

				} else if ((seMovio[3] && obs.down()) || (seMovio[3] && pos.y + (height / 2) < (escalera.pos.y))) {
					pos.y += vel.y;
				}
				System.out.println((pos.y + (height / 2) < (escalera.pos.y)) + "    ..   " + seMovio[3] + "  ...... "
						+ obs.left());
			} else {
				subir = false;
			}
		}

	}

	public boolean isSobreEscalera(Escalera e) {
		boolean isSobre = false;
		if (pos.x > e.pos.x - (e.tam.x / 2) && pos.x < e.pos.x + (e.tam.x / 2)
				&& pos.y + (height / 2) + 30 > e.pos.y - (e.tam.y / 2) && pos.y < e.pos.y + (e.tam.y / 2)) {
			isSobre = true;

		}

		return isSobre;
	}

	public boolean[] getSeMovio() {
		return seMovio;
	}

	public String toString() {
		return name + ", " + pos.x + ", " + pos.y;
	}

	public PVector getPos() {
		return pos;
	}

	public void setPos(PVector pos) {
		this.pos = pos;
	}

	public void setSeMovio(boolean[] seMovio) {
		this.seMovio = seMovio;
	}

	public void anidarReceptor(Receptor receptor) {
		this.receptor = receptor;
		this.receptor.setObserver(this);
	}

	public void controlCom(Mensaje m) {

		seMovio[0] = m.RIGHT;
		seMovio[1] = m.LEFT;

		seMovio[2] = m.UP;
		seMovio[3] = m.DOWN;

		seMovio[5] = m.ATAQUE;

		if (presion == false) {
			System.out.println(m.RESET);
			presion = m.RESET;
			if (presion) {

				if (log.pantalla < 2) {
					log.pantalla++;
				}
			}
		}

		presion = m.RESET;

		if (seMovio[2] == false) {
			seMovio[2] = m.UP;
		}

	}

	public boolean getIsVivo() {
		return isVivo;
	}

}
