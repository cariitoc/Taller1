package juego;

import java.util.ArrayList;

import Comunicacion.Servidor;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;
import processing.core.PVector;

public class Logica {

	PApplet app;
	PImage escenario;
	PImage rejas;
	Camara cam;
	Personaje jugador1;
	ArrayList<Personaje> jugadores;
	int pantalla = 0;

	PImage inicio, instrucciones, ganoSue, ganoChris;

	ArrayList<Escalera> esc;
	ArrayList<Sangre> sangre;
	ArrayList<Fantasma> fantasmas;

	public Logica(PApplet app) {
		this.app = app;

		escenario = app.loadImage("Imagenes/escena.png");
		rejas = app.loadImage("Imagenes/rejas.png");
		
		inicio = app.loadImage("Imagenes/inicio.png");
		instrucciones = app.loadImage("Imagenes/instruciones.png");
		ganoSue = app.loadImage("Imagenes/ganoSue.png");
		ganoChris = app.loadImage("Imagenes/ganoChris.png");
		
		// escenario= app.loadImage("Imagenes/negativo.png");
		jugadores = new ArrayList<Personaje>();

		cam = new Camara(this);
		cam.setImageBase(escenario);

		esc = new ArrayList<Escalera>();
		sangre = new ArrayList<Sangre>();
		sangre.add(new Sangre(this, new PVector(1015, 1465)));
		sangre.add(new Sangre(this, new PVector(374, 1464)));
		sangre.add(new Sangre(this, new PVector(374, 1238)));
		sangre.add(new Sangre(this, new PVector(970, 1012)));
		sangre.add(new Sangre(this, new PVector(877, 337)));
		sangre.add(new Sangre(this, new PVector(374, 337)));

		fantasmas = new ArrayList<>();
		fantasmas.add(new Fantasma(this, new PVector(100, 100)));
		fantasmas.add(new Fantasma(this, new PVector(1067, 127)));
		fantasmas.add(new Fantasma(this, new PVector(1061, 670)));
		fantasmas.add(new Fantasma(this, new PVector(698, 1377)));
		fantasmas.add(new Fantasma(this, new PVector(392, 1143)));
		fantasmas.add(new Fantasma(this, new PVector(407, 688)));

		esc.add(new Escalera(this, 1, new PVector(510, 1553)));
		esc.add(new Escalera(this, 1, new PVector(1137, 434)));
		esc.add(new Escalera(this, 2, new PVector(1004, 258)));
		esc.add(new Escalera(this, 2, new PVector(651, 153)));
		esc.add(new Escalera(this, 1, new PVector(1150, 1330)));
		esc.add(new Escalera(this, 1, new PVector(868, 1104)));
		esc.add(new Escalera(this, 1, new PVector(1137, 878)));
		esc.add(new Escalera(this, 1, new PVector(740, 655)));
		esc.add(new Escalera(this, 3, new PVector(1067, 1109)));
		esc.add(new Escalera(this, 1, new PVector(82, 1332)));
		esc.add(new Escalera(this, 1, new PVector(508, 1103)));
		esc.add(new Escalera(this, 3, new PVector(249, 1103)));
		esc.add(new Escalera(this, 1, new PVector(53, 880)));
		esc.add(new Escalera(this, 1, new PVector(509, 657)));
		esc.add(new Escalera(this, 1, new PVector(66, 432)));
		esc.add(new Escalera(this, 2, new PVector(171, 255)));
		esc.add(new Escalera(this, 1, new PVector(656, 1553)));

		Personaje jugador1 = new Chris(this, new PVector(1139, 1594));
		Personaje jugador2 = new Sue(this, new PVector(51, 1592));
		jugadores.add(jugador1);

		jugadores.add(jugador2);

		Servidor sever = new Servidor(this);

	}

	public void pintar() {
		app.background(255);

		switch (pantalla) {

		case 0:
			app.imageMode(PConstants.CORNER);
			app.image(inicio, 0, 0);
			
			break;
		case 1:
			app.imageMode(PConstants.CORNER);
			app.image(instrucciones, 0, 0);
			break;
		case 2:
			juego();
			break;
		case 3:
			app.imageMode(PConstants.CORNER);
			app.image(ganoSue, 0, 0);
			break;
		case 4:
			app.imageMode(PConstants.CORNER);
			app.image(ganoChris, 0, 0);
			break;

		}

	}

	public void juego() {

		cam.inicio();

		app.imageMode(PConstants.CORNER);
		app.image(escenario, 0, 0);

		for (int i = 0; i < esc.size(); i++) {
			esc.get(i).pintar();
		}

		for (int i = 0; i < esc.size(); i++) {
			Escalera esca = esc.get(i);
			esca.pintar();
			esca.validar();

		}

		for (Fantasma f : fantasmas) {
			f.pintar();
		}
		for (int i = 0; i < fantasmas.size(); i++) {
			Fantasma f = fantasmas.get(i);
			if (f.getIsVivo() == false) {
				fantasmas.remove(f);
			}
		}

		for (int i = 0; i < jugadores.size(); i++) {

			jugadores.get(i).pintar();
		}

		app.imageMode(PConstants.CORNER);
		app.image(rejas, 0, 0);

		for (int i = 0; i < sangre.size(); i++) {
			sangre.get(i).pintar();
		}

		cam.fin();

		if (jugadores.size() >= 2) {
			if (jugadores.get(0).pos.y < jugadores.get(1).pos.y) {
				cam.setPersonaje(jugadores.get(0));
			} else {
				cam.setPersonaje(jugadores.get(1));
			}
		}

	}

	public Camara getCamara() {
		return cam;
	}

	public ArrayList<Personaje> getPersonajes() {
		return jugadores;
	}

	public PApplet getPApplet() {
		return app;

	}

	public ArrayList<Escalera> getEsc() {
		return esc;
	}

}
