package juego;

public class BolaPlasma {

	public BolaPlasma() {
		// TODO Auto-generated constructor stub
	}

}
