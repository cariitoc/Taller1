package Comunicacion;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import juego.Logica;
import juego.Personaje;
import juego.Sue;
import processing.core.PVector;

public class Servidor extends Thread {

	static String IP;
	static int PUERTO = 6000;
	static ArrayList<Receptor> receptores;
	boolean vivo;
	Logica log;

	public Servidor(Logica log) {
		this.log = log;
		vivo = true;
		receptores = new ArrayList<Receptor>();
		start();
	}

	@Override
	public void run() {

		try {

			ServerSocket servers = new ServerSocket(PUERTO);
			
			while (vivo) {
				System.out.println("Enviado solisitud");
				Socket socket = servers.accept();
				System.out.println("Servidor enlazado");

				Receptor r = new Receptor(socket);
				r.start();

				receptores.add(r);

				if (receptores.size() == 1) {
					 log.getPersonajes().get(0).anidarReceptor(r);
				}else if(receptores.size() == 2){
					 log.getPersonajes().get(1).anidarReceptor(r);
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
