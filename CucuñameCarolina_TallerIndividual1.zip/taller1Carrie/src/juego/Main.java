package juego;

import processing.core.PApplet;

public class Main extends PApplet {

	Logica logica;

	public static void main(String[] args) {
		PApplet.main("juego.Main");

	}

	@Override
	public void settings() {

		size(1200, 700);
	}

	@Override
	public void setup() {

		logica = new Logica(this);
	}

	@Override
	public void draw() {
		logica.pintar();
	}

}
