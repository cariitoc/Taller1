package juego;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;
import processing.core.PVector;

public class Fantasma extends Personaje{

	
	PImage img;
	Obstaculo obs;
	boolean espera;
	private int restarVida;
	
	public Fantasma(Logica log,PVector pos) {
		super(log, pos);
		this.log = log;
		this.app=log.getPApplet();
	
		this.img = app.loadImage("Imagenes/fantasma.png");
		this.obs = new Obstaculo(log, this);
		
		this.width = img.width;
		this.height = img.height;
		
	start();

	}
	
	public void pintar() {
		app.imageMode(PConstants.CENTER);
		app.image(img, pos.x, pos.y);
		
	}
	
	public void movimiento() {
		
	
			if ((obs.limLeft() || obs.limRight()) || (!obs.left() || !obs.right())) {
				pos.x += -vel.x;
				vel.x *= -1;
			}
			
			pos.x += vel.x;
	

		if (obs.down()) {
			gravedad();
		}
		
		for(Personaje p : log.getPersonajes()) {
			validar(p);
		}
		
		if(restarVida > 0 && restarVida < 40) {
			restarVida++;
		}else {
			restarVida = 0;
		}
		
	}
	
	public void validar(Personaje p) {
		if(pos.dist(p.pos) < (width/2) + (p.width/2)) {
			if(restarVida == 0 && p.seMovio[5] == false) {
				
				p.vida -= 15;
				
			
				
				restarVida = 1;
			}else if(p.seMovio[5]){
				isVivo = false;
			}
			
			
		}
		
	}
	
	
	
	
	
	
	

	@Override
	public void Mensaje(Comunicacion.Mensaje o) {
		// TODO Auto-generated method stub
		
	}

}
