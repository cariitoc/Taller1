package juego;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

public class Escalera {
	PApplet app;
	Logica log;
	PImage escaleras;
	PVector tam;
	PVector pos;
	int tipo;


	public Escalera(Logica log, int tipo, PVector pos) {
		this.log = log;
		this.app = log.app;
		this.pos = pos;
		this.tipo = tipo;
		

		if (tipo == 1) {
			escaleras = app.loadImage("Imagenes/esc1.png");
		} else if (tipo == 2) {
			escaleras = app.loadImage("Imagenes/esc2.png");
		} else {
			escaleras = app.loadImage("Imagenes/esc3.png");
		}
		
		this.tam= new PVector(escaleras.width,escaleras.height);

	}

	public void pintar() {
		app.imageMode(app.CENTER);
		app.image(escaleras, pos.x, pos.y);

	}

	public void validar() {
		for (Personaje p : log.getPersonajes()) {
			if (pos.dist(p.getPos()) <= 200) {
				p.getSeMovio()[4] = true;
			} else {
				p.getSeMovio()[4] = false;
			}
		}

	}

	public void escalar() {
		for (Personaje p : log.getPersonajes()) {
			p.getPos().y -= 5;
		}
	}

	public PVector getPos() {
		return pos;
	}

	public void setPos(PVector pos) {
		this.pos = pos;
	}
	
	

}
