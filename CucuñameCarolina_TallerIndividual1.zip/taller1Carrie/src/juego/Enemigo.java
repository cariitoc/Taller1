package juego;

public class Enemigo {

	public Enemigo() {
		// TODO Auto-generated constructor stub
	}

}
