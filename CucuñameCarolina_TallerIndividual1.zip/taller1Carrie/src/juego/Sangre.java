package juego;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;
import processing.core.PVector;

public class Sangre extends Thread{
	
	Logica log;
	PApplet app;
	PImage padre;
	PImage hija;
	PVector posE;
	PVector posH;
	int cont;
	
	public Sangre(Logica log,PVector posE) {
		this.log = log;
		this.app=log.getPApplet();
		this.posE=posE;
		this.posH=new PVector(posE.x,posE.y);
		
		padre = app.loadImage("Imagenes/sangrePadre.png");
		hija = app.loadImage("Imagenes/sangreHija.png");
		
		cont=0;
		start();
	}
	
	public void run() {
	 while(true) {
		 try {
			cont++;
			 if(cont>200) {
				 mover();
				 validar();
			 }
			 if(cont >400) {
				 posH=new PVector(posE.x,posE.y);
				 cont=0;
			 }
			 sleep(20);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		 
	 }
	}
	
	public void validar() {
		for(Personaje p : log.getPersonajes()) {
			if(posH.dist(p.pos) < 40) {
				 posH=new PVector(posE.x,posE.y);
				 cont=0;
				restaVida(p);
			}
			
		}
	}

	public void restaVida(Personaje p) {
		p.vida -= 5;
	}
	
	public void pintar() {
		app.imageMode(PConstants.CENTER);
		app.image(padre, posE.x,posE.y);
		app.image(hija, posH.x, posH.y);
	
	}
	public void mover() {
		posH.y+=2;
		
	}

}
