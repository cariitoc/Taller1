package com.example.ecosistemas.controlcarrie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btn_verificar = findViewById(R.id.btn_verificar);

        final EditText et_ip = findViewById(R.id.et_ip);
        final EditText et_puerto = findViewById(R.id.et_puerto);
        final EditText et_name = findViewById(R.id.et_nombre);

        btn_verificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent juego = new Intent(MainActivity.this, Main2Activity.class);

                String ip = et_ip.getText().toString();

                int puerto = 0;
                try {
                    puerto = Integer.parseInt(et_puerto.getText().toString());
                }catch(Exception e){
                    puerto = 0;
                }

                String name = et_name.getText().toString();

                Bundle b = new Bundle();
                b.putString("numIp", ip);

                Bundle c = new Bundle();
                c.putInt("puerto", puerto);

                Bundle e = new Bundle();
                e.putString("nombre", name);

                juego.putExtras(b);
                juego.putExtras(c);
                juego.putExtras(e);

                if(puerto !=0 && !ip.equals("")){
                    startActivity(juego);
                }else{
                    Toast.makeText(MainActivity.this, "Introduce datos validos", Toast.LENGTH_SHORT).show();
                }



            }
        });

    }
}
