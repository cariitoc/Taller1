package com.example.ecosistemas.controlcarrie;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import Comunicacion.Cliente;
import Comunicacion.Mensaje;

public class Main2Activity extends AppCompatActivity implements View.OnTouchListener{

    Cliente cliente;
    String name;
    Mensaje m = new Mensaje();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
     //   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        Bundle datos = getIntent().getExtras();

        String ip = datos.getString("numIp");
        int puerto = datos.getInt("puerto");
        this.name = datos.getString("nombre");

        System.out.println(ip + "  " + puerto + "    " + name);
        cliente = new Cliente(ip, puerto);
        cliente.start();

        ImageButton up = findViewById(R.id.btn_up);
        ImageButton down = findViewById(R.id.btn_down);
        ImageButton left = findViewById(R.id.btn_left);
        ImageButton right = findViewById(R.id.btn_right);
        ImageButton back = findViewById(R.id.btn_back);
        ImageButton action = findViewById(R.id.btn_action);


        up.setOnTouchListener(this);
        down.setOnTouchListener(this);
        left.setOnTouchListener(this);
        right.setOnTouchListener(this);
        back.setOnTouchListener(this);
        action.setOnTouchListener(this);


    }

    public void enviar(String accion){
        m.NAME = this.name;
        switch (accion){
            case "left":
                m.LEFT = true;
                break;
            case "right":
                m.RIGHT = true;
                break;
            case "up":
                m.UP = true;
                break;

            case "down":
                m.DOWN = true;
                break;

            case "accion":
                m.ATAQUE = true;
                break;
            case "reset":
                m.RESET = true;
                break;

        }
        cliente.getReceptor().enviar(m);
    }

    public void enviarReleased(String accion){
        m.NAME = this.name;
        switch (accion){
            case "left":
                m.LEFT = false;
                break;
            case "right":
                m.RIGHT = false;
                break;
            case "up":
                m.UP = false;
                break;

            case "down":
                m.DOWN = false;
                break;

            case "accion":
                m.ATAQUE = false;
                break;
            case "reset":
                m.RESET = false;
                break;

        }
        cliente.getReceptor().enviar(m);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN) {
            switch (v.getId()) {
                case R.id.btn_up:
                    enviar("up");
                    break;

                case R.id.btn_down:
                    enviar("down");
                    break;

                case R.id.btn_left:
                    enviar("left");

                    break;

                case R.id.btn_right:

                    enviar("right");
                    break;

                case R.id.btn_back:
                    enviar("reset");
                    break;

                case R.id.btn_action:
                    enviar("accion");
                    break;

            }
        }else if(event.getAction() == MotionEvent.ACTION_UP){
            switch (v.getId()) {
                case R.id.btn_up:
                    enviarReleased("up");
                    break;

                case R.id.btn_down:
                    enviarReleased("down");
                    break;

                case R.id.btn_left:
                    enviarReleased("left");

                    break;

                case R.id.btn_right:

                    enviarReleased("right");
                    break;

                case R.id.btn_back:
                    enviarReleased("reset");
                    break;

                case R.id.btn_action:
                    enviarReleased("accion");
                    break;

            }
        }
        return false;
    }
}
