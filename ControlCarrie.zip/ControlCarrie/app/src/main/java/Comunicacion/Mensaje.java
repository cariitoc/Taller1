package Comunicacion;

import java.io.Serializable;

public class Mensaje implements Serializable{

	public String NAME;
	public boolean UP;
	public boolean DOWN;
	public boolean RIGHT;
	public boolean LEFT;
	public boolean ATAQUE;
	public boolean RESET;
}
