package Comunicacion;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Cliente extends Thread{

	static String IP;
	static int PUERTO = 5000;
	public static Receptor receptor;

	public Cliente(String IP, int puerto) {
		this.IP = IP;
		this.PUERTO = puerto;
	}

	@Override
	public void run() {



		try {
			System.out.println("Intentando ...............................................................");
			Socket socket = new Socket(IP, PUERTO);
			System.out.println("Concesncion exitosa ...............................................................");

			receptor = new Receptor(socket);
			receptor.start();



		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Receptor getReceptor() {
		return receptor;
	}
}

